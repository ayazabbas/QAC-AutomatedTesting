package tests;

import org.junit.Test;

public class HelloJUnit {

	@Test
	public void test() {
		System.out.println("Hello World");
	}

}
